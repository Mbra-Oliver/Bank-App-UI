import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Image,
} from 'react-native';
import React from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import FontAwesome from 'react-native-vector-icons/FontAwesome';

const windowHeight = Dimensions.get('window').height;
const Transaction = ({navigation}) => {
  return (
    <ScrollView style={styles.root}>
      {/* Header */}

      <View style={styles.header}>
        {/* Item du header */}
        <View style={styles.headerItems}>
          <TouchableOpacity style={styles.headerItems_item_inactive}>
            <AntDesign
              name="wallet"
              size={20}
              color="#fff"
              style={{marginRight: 5}}
            />
            <Text style={styles.headerItems__text_unactive}>Portefeuille</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerItems_item}
            onPress={() => navigation.navigate('transactions')}>
            <AntDesign
              name="wallet"
              size={20}
              color="#fff"
              style={{marginRight: 5}}
            />
            <Text style={styles.headerItems__text}>Transactions</Text>
          </TouchableOpacity>
        </View>

        {/* Montant Du COmpte */}

        <View style={styles.accountView}>
          <Text style={styles.accountValue}>Transactions</Text>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <FontAwesome
              name="dollar"
              size={15}
              color="#fff"
              style={{marginRight: 5}}
            />
            <Text style={styles.accountValue}> 2.000.000</Text>
          </View>
        </View>
      </View>

      <View style={styles.dayContainer}>
        <View style={styles.accountTextContainer}>
          <Text style={styles.accountTextContainer_text}> Aujourd'hui</Text>
        </View>

        {/* Days Items */}

        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Paiement de code
              </Text>
              <Text>Codepen</Text>
            </View>
          </View>

          <Text style={{color: 'red', fontFamily: 'OpenSans-Bold'}}>
            - 3000$
          </Text>
        </View>

        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Reception de fond
              </Text>
              <Text>Vente de code</Text>
            </View>
          </View>

          <Text style={{color: 'green', fontFamily: 'OpenSans-Bold'}}>
            +3000$
          </Text>
        </View>
      </View>
      <View style={styles.dayContainer}>
        <View style={styles.accountTextContainer}>
          <Text style={styles.accountTextContainer_text}> Hier</Text>
        </View>

        {/* Days Items */}

        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Reception de fond
              </Text>
              <Text>Formation en ligne</Text>
            </View>
          </View>

          <Text style={{color: 'green', fontFamily: 'OpenSans-Bold'}}>
            + 5000$
          </Text>
        </View>
      </View>
      <View style={styles.dayContainer}>
        <View style={styles.accountTextContainer}>
          <Text style={styles.accountTextContainer_text}> 10 Juillet 2022</Text>
        </View>

        {/* Days Items */}

        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Reception de fond
              </Text>
              <Text>Formation en ligne</Text>
            </View>
          </View>

          <Text style={{color: 'green', fontFamily: 'OpenSans-Bold'}}>
            + 50$
          </Text>
        </View>
        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Reception de fond
              </Text>
              <Text>Formation en ligne</Text>
            </View>
          </View>

          <Text style={{color: 'green', fontFamily: 'OpenSans-Bold'}}>
            + 50$
          </Text>
        </View>
        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Reception de fond
              </Text>
              <Text>Formation en ligne</Text>
            </View>
          </View>

          <Text style={{color: 'green', fontFamily: 'OpenSans-Bold'}}>
            + 50$
          </Text>
        </View>
        <View style={styles.daysItemContainer}>
          {/* Vue pour l'icone et les libelle */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <AntDesign
              name="codepen-circle"
              size={30}
              color="#000"
              style={{marginRight: 15}}
            />

            <View>
              <Text
                style={{
                  color: '#000',
                  fontFamily: 'OpenSans-Bold',
                  marginBottom: 2,
                }}>
                Reception de fond
              </Text>
              <Text>Formation en ligne</Text>
            </View>
          </View>

          <Text style={{color: 'green', fontFamily: 'OpenSans-Bold'}}>
            + 50$
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

export default Transaction;

const styles = StyleSheet.create({
  root: {
    backgroundColor: '#edf1f2',
  },

  header: {
    backgroundColor: '#154ee7',
    height: windowHeight * 0.18,

    paddingHorizontal: 20,
  },
  headerItems: {
    marginTop: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerItems_item: {
    flexDirection: 'row',
    backgroundColor: '#1d50b1',
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginRight: 5,
    borderRadius: 15,
  },
  headerItems_item_inactive: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginRight: 5,
    borderRadius: 15,
  },
  headerItems__text: {
    color: '#fff',
    fontFamily: 'OpenSans-Regular',
  },
  headerItems__text_unactive: {
    color: '#eee',
    fontFamily: 'OpenSans-Regular',
  },
  accountView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    fontFamily: 'OpenSans-Regular',
    marginTop: 30,
  },

  accountValue: {
    color: '#fff',
    fontFamily: 'OpenSans-Regular',
    fontSize: 18,
  },

  accountTextContainer: {
    padding: 15,
    marginTop: 15,
  },
  accountTextContainer_text: {
    color: '#000',
    fontWeight: 'bold',
    fontFamily: 'OpenSans-Regular',
  },
  dayContainer: {
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#edf1f2',
    marginBottom: 5,
  },
  daysItemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#edf1f2',
  },
});
