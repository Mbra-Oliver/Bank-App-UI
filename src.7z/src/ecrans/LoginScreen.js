import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import LogoSvg from './../../assets/images/svg/undraw_segment_re_a3e7.svg';

import TwitterSvg from './../../assets/images/svg/twitter.svg';
import GoogleSvg from './../../assets/images/svg/Google.svg';
import FacebookSvg from './../../assets/images/svg/facebook.svg';

const LoginScreen = ({navigation}) => {
  return (
    <SafeAreaView style={styles.root}>
      <LogoSvg width={300} height={200} />
      <Text style={styles.title}>React Native - Tutoriel</Text>

      {/* Zone de saisie */}

      <View style={styles.inputContainer}>
        <Entypo name="email" size={20} color="#666" style={{marginRight: 5}} />
        <TextInput style={styles.input} placeholder={'Entrer votre email'} />
      </View>
      <View style={styles.inputContainer}>
        <MaterialCommunityIcons
          name="security"
          size={20}
          color="#666"
          style={{marginRight: 5}}
        />
        <TextInput style={styles.input} secureTextEntry />

        <TouchableOpacity>
          <Text style={{color: '#0065ff'}}>Oublié ?</Text>
        </TouchableOpacity>
      </View>

      {/* Button Action */}

      <TouchableOpacity style={styles.touchableButton}>
        <Text style={styles.touchableText}>Me Connecter</Text>
      </TouchableOpacity>

      <View>
        <Text style={styles.textCenter}>Me connecter avec </Text>
      </View>

      <View style={styles.svgRow}>
        <TouchableOpacity style={styles.svgButton}>
          <GoogleSvg width={24} height={24} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.svgButton}>
          <TwitterSvg width={24} height={24} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.svgButton}>
          <FacebookSvg width={24} height={24} />
        </TouchableOpacity>
      </View>

      <View
        style={{
          marginTop: 20,
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Text style={{textAlign: 'center'}}>Nouveau ?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('inscription')}>
          <Text style={{color: '#0065ff', marginLeft: 3}}>Crée un compte.</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 25,
    backgroundColor: '#fff',
  },

  title: {
    fontSize: 28,
    fontWeight: '500',
    color: '#333',
    marginBottom: 30,
  },

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    paddingHorizontal: 8,
    marginBottom: 25,
  },

  input: {
    flex: 1,
  },

  touchableButton: {
    marginBottom: 30,
    borderRadius: 5,
    padding: 20,
    backgroundColor: '#0065ff',
  },
  touchableText: {
    textAlign: 'center',
    fontWeight: '700',
    fontSize: 16,
    color: '#fff',
  },

  textCenter: {
    textAlign: 'center',
    fontWeight: '700',
    fontSize: 16,
  },

  svgRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 30,
  },
  svgButton: {
    borderColor: '#ddd',
    borderWidth: 2,
    borderRadius: 10,
    paddingHorizontal: 30,
    paddingVertical: 10,
  },
});
