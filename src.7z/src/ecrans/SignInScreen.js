import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import React, {useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import LogoSvg from './../../assets/images/svg/undraw_segment_re_a3e7.svg';

import TwitterSvg from './../../assets/images/svg/twitter.svg';
import GoogleSvg from './../../assets/images/svg/Google.svg';
import FacebookSvg from './../../assets/images/svg/facebook.svg';

import DatePicker from 'react-native-date-picker';
import moment from 'moment/moment';

const SignInScreen = ({navigation}) => {
  moment.locale('fr');
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [birthDate, setBirthDate] = useState(undefined);

  return (
    <SafeAreaView style={styles.root}>
      <Text style={styles.title}>S'Inscrire</Text>

      {/* Zone de saisie */}

      <View style={styles.inputContainer}>
        <Ionicons
          name="person-outline"
          size={20}
          color="#666"
          style={{marginRight: 5}}
        />
        <TextInput
          style={styles.input}
          placeholder={'Entrer votre Nom Complet'}
        />
      </View>

      <View style={styles.inputContainer}>
        <AntDesign
          name="phone"
          size={20}
          color="#666"
          style={{marginRight: 5}}
        />
        <TextInput style={styles.input} placeholder={'Entrer votre contact'} />
      </View>

      <View style={styles.inputContainer}>
        <Entypo
          name="calendar"
          size={20}
          color="#666"
          style={{marginRight: 5}}
        />
        <TouchableOpacity
          onPress={() => setOpen(true)}
          style={{flex: 1, paddingVertical: 5}}>
          <Text>
            {birthDate === undefined
              ? 'Date de naissance'
              : moment(birthDate).format('DD-MM-YYYY')}
          </Text>
        </TouchableOpacity>
      </View>

      {/* DatePicker */}
      <DatePicker
        modal
        open={open}
        date={date}
        mode={'date'}
        minimumDate={new Date('1999-01-01')}
        maximumDate={new Date('2012-01-01')}
        locale={'fr'}
        title={'Date de naissance'}
        onConfirm={date => {
          setOpen(false);
          setDate(date);
          setBirthDate(date.toDateString());
        }}
        onCancel={() => {
          setOpen(false);
        }}
      />

      {/* FIn Darte Picker */}

      <View style={styles.inputContainer}>
        <Entypo name="email" size={20} color="#666" style={{marginRight: 5}} />
        <TextInput style={styles.input} placeholder={'Entrer votre email'} />
      </View>

      <View style={styles.inputContainer}>
        <Ionicons
          name="ios-lock-closed-outline"
          size={20}
          color="#666"
          style={{marginRight: 5}}
        />
        <TextInput
          style={styles.input}
          secureTextEntry
          placeholder="Mot de passe"
        />
      </View>
      <View style={styles.inputContainer}>
        <Ionicons
          name="ios-lock-closed-outline"
          size={20}
          color="#666"
          style={{marginRight: 5}}
        />
        <TextInput
          style={styles.input}
          secureTextEntry
          placeholder="Mot de passe"
        />
      </View>

      {/* Button Action */}

      <TouchableOpacity style={styles.touchableButton}>
        <Text style={styles.touchableText}>M'Inscrire</Text>
      </TouchableOpacity>

      <View>
        <Text style={styles.textCenter}>M'inscrire avec </Text>
      </View>

      <View style={styles.svgRow}>
        <TouchableOpacity style={styles.svgButton}>
          <GoogleSvg width={24} height={24} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.svgButton}>
          <TwitterSvg width={24} height={24} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.svgButton}>
          <FacebookSvg width={24} height={24} />
        </TouchableOpacity>
      </View>

      <View
        style={{
          marginTop: 20,
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Text style={{textAlign: 'center'}}>Déja un compte ?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('connexion')}>
          <Text style={{color: '#0065ff', marginLeft: 3}}>Me connecter.</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default SignInScreen;
const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 25,
    backgroundColor: '#fff',
  },

  title: {
    fontSize: 28,
    fontWeight: '500',
    color: '#333',
    marginBottom: 30,
  },

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    paddingHorizontal: 8,
    marginBottom: 25,
  },

  input: {
    flex: 1,
  },

  touchableButton: {
    marginBottom: 30,
    borderRadius: 5,
    padding: 20,
    backgroundColor: '#0065ff',
  },
  touchableText: {
    textAlign: 'center',
    fontWeight: '700',
    fontSize: 16,
    color: '#fff',
  },

  textCenter: {
    textAlign: 'center',
    fontWeight: '700',
    fontSize: 16,
  },

  svgRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 30,
  },
  svgButton: {
    borderColor: '#ddd',
    borderWidth: 2,
    borderRadius: 10,
    paddingHorizontal: 30,
    paddingVertical: 10,
  },
});
